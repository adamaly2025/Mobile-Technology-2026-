package com.example.mbt_group_assignment_2;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;

public class Activity_2 extends AppCompatActivity {
    private static final int REQUEST_PERMISSION = 3000;
    private Uri imageFileUri;
    private ImageView imageView;
    private TextView textViewTitle, textViewResult;
    private Button buttonEdit;
    private String readerType;
    private String mlKitResult = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imageView = findViewById(R.id.imageView2);
        textViewTitle = findViewById(R.id.textViewTitle2);
        textViewResult = findViewById(R.id.textViewResult);
        buttonEdit = findViewById(R.id.buttonEditResult);
        
        readerType = getIntent().getStringExtra("readerType");

        if ("Barcode Reader".equals(readerType)) {
            imageView.setImageResource(R.drawable.barcode);
        } else if ("Content Reader".equals(readerType)) {
            imageView.setImageResource(R.drawable.content);
        } else {
            imageView.setImageResource(R.drawable.text);
        }
    }

    private void updateUIAfterML() {
        textViewTitle.setText(readerType);
        textViewResult.setText(mlKitResult);
        buttonEdit.setVisibility(View.VISIBLE);
    }

    public void openCamera(View view) {
        if (!checkPermission())
            return;
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(intent);
    }

    public void loadImage(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(intent);
    }

    ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK) {
                            if (result.getData() != null && result.getData().getData() != null)
                                imageFileUri = result.getData().getData();
                            imageView.setImageURI(imageFileUri);
                            textViewResult.setText("");
                            InputImage image = null;
                            try { image = InputImage.fromFilePath(this, imageFileUri); }
                            catch (IOException e) { e.printStackTrace(); }
                            if (image != null) {
                                if ("Barcode Reader".equals(readerType))
                                    processBarcode(image);
                                else if ("Content Reader".equals(readerType))
                                    processContent(image);
                                else
                                    processText(image);
                            }
                        }
                    });

    private void processBarcode(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanning.getClient(options).process(image)
                .addOnSuccessListener(barcodes -> {
                    StringBuilder sb = new StringBuilder("Detected barcode:\n");
                    int i = 1;
                    for (Barcode b : barcodes) sb.append(i++).append(". ").append(b.getRawValue()).append("\n");
                    if (barcodes.isEmpty()) sb.append("Barcode not found.");
                    mlKitResult = sb.toString();
                    updateUIAfterML();
                })
                .addOnFailureListener(e -> textViewResult.setText("Failed"));
    }

    private void processContent(InputImage image) {
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
                .process(image)
                .addOnSuccessListener(labels -> {
                    StringBuilder sb = new StringBuilder("Recognised image content:\n");
                    int i = 1;
                    for (ImageLabel l : labels) {
                        sb.append(i++).append(". ")
                                .append(l.getText())
                                .append(": (")
                                .append(String.format("%.2f", l.getConfidence() * 100))
                                .append("% confidence)\n");
                    }
                    if (labels.isEmpty()) sb.append("Nothing found.");
                    mlKitResult = sb.toString();
                    updateUIAfterML();
                })
                .addOnFailureListener(e -> textViewResult.setText("Failed"));
    }

    private void processText(InputImage image) {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(image)
                .addOnSuccessListener(text -> {
                    String result = text.getText();
                    StringBuilder sb = new StringBuilder("Extracted text:\n");
                    if (result.length() > 0) {
                        String[] lines = result.split("\n");
                        int i = 1;
                        for (String line : lines) {
                            if (!line.trim().isEmpty()) {
                                sb.append(i++).append(". ").append(line.trim()).append("\n");
                            }
                        }
                    } else {
                        sb.append("No text found.");
                    }
                    mlKitResult = sb.toString();
                    updateUIAfterML();
                })
                .addOnFailureListener(e -> textViewResult.setText("Failed"));
    }

    private boolean checkPermission() {
        String permission = android.Manifest.permission.CAMERA;
        boolean granted = ContextCompat.checkSelfPermission(this, permission)
                == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, REQUEST_PERMISSION);
        }
        return granted;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera(null);
            } else {
                textViewResult.setText("Permission denied. Cannot open camera.");
            }
        }
    }

    public void editResult(View view) {
        if (imageFileUri == null) {
            textViewResult.setText("Please capture or load an image first.");
            return;
        }
        Intent intent = new Intent(this, Activity_5.class);
        intent.putExtra("readerType", readerType);
        intent.putExtra("mlResult", mlKitResult);
        intent.putExtra("imageUri", imageFileUri.toString());
        intent.putExtra("isNew", true);
        startActivity(intent);
    }
}