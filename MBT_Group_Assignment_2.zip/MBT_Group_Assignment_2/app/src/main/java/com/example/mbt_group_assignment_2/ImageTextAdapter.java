package com.example.mbt_group_assignment_2;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ImageTextAdapter extends BaseAdapter {
    private Context context;
    private List<DataItem> items;

    public ImageTextAdapter(Context ctx, List<DataItem> items) {
        this.context = ctx; this.items = items;
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int pos) { return items.get(pos); }
    @Override public long getItemId(int pos) { return pos; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.list_item, parent, false);
        if (position % 2 == 0)
            convertView.setBackgroundColor(Color.LTGRAY);
        else
            convertView.setBackgroundColor(Color.WHITE);
        DataItem item = items.get(position);
        ImageView img = convertView.findViewById(R.id.listItemImage);
        TextView txt = convertView.findViewById(R.id.listItemText);
        txt.setText(item.reader);
        loadImage(img, item.filename);
        return convertView;
    }

    private void loadImage(ImageView iv, String filename) {
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] proj = { MediaStore.Images.Media._ID };
        String sel = MediaStore.Images.Media.DISPLAY_NAME + "=?";
        Cursor c = context.getContentResolver().query(uri, proj, sel,
                new String[]{filename + ".jpg"}, null);
        if (c != null && c.moveToFirst()) {
            long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
            Uri imgUri = ContentUris.withAppendedId(uri, id);
            iv.setImageURI(imgUri);
            c.close();
        }
    }
}

