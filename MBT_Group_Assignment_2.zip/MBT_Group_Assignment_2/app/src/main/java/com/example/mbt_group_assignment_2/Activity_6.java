package com.example.mbt_group_assignment_2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Activity_6 extends AppCompatActivity {
    private ListView listView;
    private List<DataItem> itemList = new ArrayList<>();
    private ImageTextAdapter adapter;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);
        listView = findViewById(R.id.listView);
        adapter = new ImageTextAdapter(this, itemList);
        listView.setAdapter(adapter);
        dbRef = FirebaseDatabase.getInstance().getReference("Storage");
        loadFromFirebase();
        listView.setOnItemClickListener((parent, view, pos, id) -> {
            DataItem item = itemList.get(pos);
            Intent intent = new Intent(this, Activity_7.class);
            intent.putExtra("firebaseKey", item.key);
            intent.putExtra("readerType", item.reader);
            intent.putExtra("mlResult", item.text);
            intent.putExtra("filename", item.filename);
            startActivity(intent);
        });
    }

    private void loadFromFirebase() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                itemList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    DataItem d = new DataItem();
                    d.key = child.getKey();
                    d.filename = child.child("filename").getValue(String.class);
                    d.reader = child.child("reader").getValue(String.class);
                    d.text = child.child("text").getValue(String.class);
                    itemList.add(d);
                }
                adapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(DatabaseError e) {}
        });
    }

    public void addNew(View view) {
        startActivity(new Intent(this, MainActivity.class));
    }
}
