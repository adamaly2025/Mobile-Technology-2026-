package com.example.mbt_group_assignment_2;

public class DataItem {
    public String key;       // Firebase key
    public String filename;  // stored image filename
    public String reader;    // e.g. "Barcode Reader"
    public String text;      // ML Kit results
}

