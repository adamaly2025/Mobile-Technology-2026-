package com.example.mbt_group_assignment_2;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Activity_7 extends AppCompatActivity {
    private String firebaseKey, filename, readerType, mlResult;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);
        dbRef = FirebaseDatabase.getInstance().getReference("Storage");
        firebaseKey = getIntent().getStringExtra("firebaseKey");
        readerType = getIntent().getStringExtra("readerType");
        mlResult = getIntent().getStringExtra("mlResult");
        filename = getIntent().getStringExtra("filename");

        ((TextView)findViewById(R.id.textViewReader7)).setText(readerType);
        ((TextView)findViewById(R.id.textViewResult7)).setText(mlResult);
        loadImage((ImageView)findViewById(R.id.imageView7), filename);
    }

    private void loadImage(ImageView iv, String fname) {
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] proj = { MediaStore.Images.Media._ID };
        String sel = MediaStore.Images.Media.DISPLAY_NAME + "=?";
        Cursor c = getContentResolver().query(uri, proj, sel,
                new String[]{fname + ".jpg"}, null);
        if (c != null && c.moveToFirst()) {
            long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
            iv.setImageURI(ContentUris.withAppendedId(uri, id));
            c.close();
        }
    }

    public void editItem(View view) {
        Intent intent = new Intent(this, Activity_5.class);
        intent.putExtra("readerType", readerType);
        intent.putExtra("mlResult", mlResult);
        intent.putExtra("filename", filename);
        intent.putExtra("firebaseKey", firebaseKey);
        intent.putExtra("isNew", false);
        startActivity(intent);
    }

    public void deleteItem(View view) {
        dbRef.child(firebaseKey).removeValue();
        startActivity(new Intent(this, Activity_6.class));
        finish();
    }

    public void cancelItem(View view) {
        startActivity(new Intent(this, Activity_6.class));
        finish();
    }
}
