package com.example.mbt_group_assignment_2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void openBarcodeReader(View view) {
        Intent intent = new Intent(this, Activity_2.class);
        intent.putExtra("readerType", "Barcode Reader");
        startActivity(intent);
    }

    public void openContentReader(View view) {
        Intent intent = new Intent(this, Activity_2.class);
        intent.putExtra("readerType", "Content Reader");
        startActivity(intent);
    }

    public void openTextReader(View view) {
        Intent intent = new Intent(this, Activity_2.class);
        intent.putExtra("readerType", "Text Reader");
        startActivity(intent);
    }

    public void openListView(View view) {
        startActivity(new Intent(this, Activity_6.class));
    }
}