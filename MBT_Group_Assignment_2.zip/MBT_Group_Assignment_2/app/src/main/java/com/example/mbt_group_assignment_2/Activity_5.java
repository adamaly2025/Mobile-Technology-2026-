package com.example.mbt_group_assignment_2;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.OutputStream;

public class Activity_5 extends AppCompatActivity {
    private EditText editReader, editResult;
    private ImageView imageView5;
    private Uri imageUri;
    private boolean isNew;
    private String existingKey, filename;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_5);
        editReader = findViewById(R.id.editTextReader);
        editResult = findViewById(R.id.editTextResult);
        imageView5 = findViewById(R.id.imageView5);
        dbRef = FirebaseDatabase.getInstance().getReference("Storage");

        editReader.setText(getIntent().getStringExtra("readerType"));
        editResult.setText(getIntent().getStringExtra("mlResult"));
        String uriStr = getIntent().getStringExtra("imageUri");
        isNew = getIntent().getBooleanExtra("isNew", true);
        existingKey = getIntent().getStringExtra("firebaseKey");
        filename = getIntent().getStringExtra("filename");

        if (uriStr != null) {
            imageUri = Uri.parse(uriStr);
            imageView5.setImageURI(imageUri);
        } else if (filename != null) {
            loadImageFromGallery(filename);
        }
    }

    private void loadImageFromGallery(String fname) {
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.Media._ID};
        String selection = MediaStore.Images.Media.DISPLAY_NAME + "=?";
        String[] selectionArgs = new String[]{fname + ".jpg"};

        try (Cursor cursor = getContentResolver().query(uri, projection, selection, selectionArgs, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
                Uri imgUri = ContentUris.withAppendedId(uri, id);
                imageView5.setImageURI(imgUri);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveData(View view) {
        String reader = editReader.getText().toString();
        String result = editResult.getText().toString();

        if (isNew) {
            String newFilename = "IMG_" + System.currentTimeMillis();
            saveImageToGallery(newFilename);
            DatabaseReference newRef = dbRef.push();
            newRef.child("filename").setValue(newFilename);
            newRef.child("reader").setValue(reader);
            newRef.child("text").setValue(result)
                    .addOnCompleteListener(task -> {
                        startActivity(new Intent(this, Activity_6.class));
                        finish();
                    });
        } else {
            dbRef.child(existingKey).child("reader").setValue(reader);
            dbRef.child(existingKey).child("text").setValue(result)
                    .addOnCompleteListener(task -> {
                        startActivity(new Intent(this, Activity_6.class));
                        finish();
                    });
        }
    }

    private void saveImageToGallery(String fname) {
        try {
            Bitmap bitmap;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(), imageUri));
            } else {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
            }

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fname + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MBT_App");
            }
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri != null) {
                OutputStream out = getContentResolver().openOutputStream(uri);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
                out.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
        }
    }
}
